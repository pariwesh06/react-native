/*
 * @flow
 */
import invariant from '../utils/invariant';

export default () =>
  invariant(
    false,
    '`getScreenConfig` has been replaced with `getScreenOptions`'
  );
