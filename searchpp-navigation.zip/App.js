import React, { Component } from 'react';
import {
  Platform, StyleSheet, Text, View, TextInput, Button, Picker,
  FlatList } from 'react-native';
import { StackNavigator } from 'react-navigation';
import Form from './components/Form';
import Details from './components/details';
export default class App extends Component {
  render() {
    return (<Router ></Router>)
  }
}
const mappings = {
  Home: { screen: Form },
  details:{screen:Details}
}
const navigationConfiguration = {
  initialRouteName: 'Home'
}
const Router = StackNavigator(mappings, navigationConfiguration);