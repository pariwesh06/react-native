import React, { Component } from 'react';
import {
  Platform, StyleSheet, Text, View, TextInput, Button, Picker,
  FlatList
} from 'react-native';
export default class App extends Component<Props> {
  constructor(props) {
    super(props);
    this.state = {
      users: [],
      language: 'javascript',
      user: 'ram'
    };
  }
  search() {
    var promise = fetch('http://it-ebooks-api.info/v1/search/angular');
    promise.then((response) => {
      response.json().then((data) => {
        console.log(data.Books);
        this.setState({ users: data.Books });
      });
    })
    //logic
  }
  gotoDetails(){
    // console.log(this.props.navigation);
    this.props.navigation.navigate("details");
  }
  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.welcome}>
          Userform, {this.state.language}
        </Text>
        <TextInput value={this.state.user} onChangeText={(text) => this.setState({ user: text })} />
        <Button onPress={this.search.bind(this)} title="search" />
        <Button onPress={this.gotoDetails.bind(this)} title="go to details" />
        
        <Picker
          selectedValue={this.state.language}
          style={{ height: 50, width: 300, backgroundColor: 'red' }}
          onValueChange={(itemValue, itemIndex) => this.setState({ language: itemValue })}>
          {this.state.users.map(item => {
            return <Picker.Item label={item.Title} value={item.ID} />
          })
          }

        </Picker>
        <FlatList
          data={this.state.users}
          renderItem={(book) => <Text>{book.Title}</Text>}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});