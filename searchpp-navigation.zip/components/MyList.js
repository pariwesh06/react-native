import React, { Component } from 'react';
import {
  Platform, StyleSheet, Text, View, TextInput, Button, Picker, FlatList
} from 'react-native';

export default class MyList extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (<View>List
      <FlatList
        data={this.props.allUsers}
        renderItem={(item) => <Text>{item.Title}</Text>}
      />
    </View>)
  }
}