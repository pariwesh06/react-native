import React, { Component } from 'react';
import {
  Platform, StyleSheet, Text, View, TextInput, Button, Picker,
  FlatList
} from 'react-native';

export default class Details extends Component{
  render(){
    return (<Text> Details</Text>)
  }
}